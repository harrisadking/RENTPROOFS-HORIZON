
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash } from "lucide-react";

const AdminTemplates = () => {
  const templates = [
    { 
      id: 1, 
      name: "Standard Receipt", 
      description: "Basic receipt template with essential fields",
      status: "Active"
    },
    { 
      id: 2, 
      name: "Premium Receipt", 
      description: "Detailed receipt with company branding",
      status: "Active"
    },
    // Add more mock data as needed
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Receipt Templates</h2>
        <Button className="bg-green-600 hover:bg-green-700">
          <Plus className="h-5 w-5 mr-2" />
          New Template
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {templates.map((template) => (
          <motion.div
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-lg p-6"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold mb-2">{template.name}</h3>
                <p className="text-gray-600">{template.description}</p>
              </div>
              <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-600">
                {template.status}
              </span>
            </div>
            
            <div className="flex gap-4 mt-6">
              <Button variant="outline" className="flex-1">
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <Button variant="outline" className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50">
                <Trash className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AdminTemplates;


import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const AdminSettings = () => {
  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-lg p-8"
      >
        <h2 className="text-2xl font-bold mb-6">Email Settings</h2>
        <div className="space-y-6">
          <div>
            <Label htmlFor="reminderDay">Send Monthly Reminders On</Label>
            <Select defaultValue="1">
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select day of month" />
              </SelectTrigger>
              <SelectContent>
                {[...Array(28)].map((_, i) => (
                  <SelectItem key={i + 1} value={String(i + 1)}>
                    {i + 1}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="reminderTemplate">Reminder Email Template</Label>
            <textarea
              id="reminderTemplate"
              className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2 text-sm min-h-[150px]"
              placeholder="Enter email template..."
              defaultValue="Dear {user},&#10;&#10;This is a reminder that your rent payment of {amount} is due on {date}.&#10;&#10;Best regards,&#10;RentProofs Team"
            />
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-3xl shadow-lg p-8"
      >
        <h2 className="text-2xl font-bold mb-6">Payment Settings</h2>
        <div className="space-y-6">
          <div>
            <Label htmlFor="stripePubKey">Stripe Publishable Key</Label>
            <Input
              id="stripePubKey"
              type="text"
              placeholder="pk_test_..."
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="stripeSecretKey">Stripe Secret Key</Label>
            <Input
              id="stripeSecretKey"
              type="password"
              placeholder="sk_test_..."
              className="mt-2"
            />
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-3xl shadow-lg p-8"
      >
        <h2 className="text-2xl font-bold mb-6">System Settings</h2>
        <div className="space-y-6">
          <div>
            <Label htmlFor="maxFileSize">Maximum File Size (MB)</Label>
            <Input
              id="maxFileSize"
              type="number"
              defaultValue="10"
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="retentionPeriod">Data Retention Period (days)</Label>
            <Input
              id="retentionPeriod"
              type="number"
              defaultValue="365"
              className="mt-2"
            />
          </div>
        </div>
      </motion.div>

      <div className="flex justify-end">
        <Button className="bg-green-600 hover:bg-green-700">
          Save Changes
        </Button>
      </div>
    </div>
  );
};

export default AdminSettings;

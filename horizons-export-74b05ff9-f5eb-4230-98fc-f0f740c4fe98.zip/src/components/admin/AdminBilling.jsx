
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { DollarSign, TrendingUp, Users, Package } from "lucide-react";

const AdminBilling = () => {
  const subscriptionStats = [
    { 
      title: "Monthly Revenue", 
      value: "$12,345", 
      trend: "+15%",
      icon: DollarSign 
    },
    { 
      title: "Active Subscriptions", 
      value: "890", 
      trend: "+5%",
      icon: Users 
    },
    { 
      title: "Premium Users", 
      value: "456", 
      trend: "+10%",
      icon: Package 
    },
    { 
      title: "Growth Rate", 
      value: "23%", 
      trend: "+2%",
      icon: TrendingUp 
    }
  ];

  const recentTransactions = [
    {
      id: 1,
      user: "John Doe",
      amount: "$9.99",
      date: "2023-09-15",
      status: "Completed",
      plan: "Premium"
    },
    {
      id: 2,
      user: "Jane Smith",
      amount: "$5.99",
      date: "2023-09-14",
      status: "Completed",
      plan: "Basic"
    },
    // Add more mock data as needed
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {subscriptionStats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-3xl shadow-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="h-12 w-12 bg-green-100 rounded-2xl flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-green-600 font-medium">{stat.trend}</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stat.value}</h3>
            <p className="text-gray-600">{stat.title}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-3xl shadow-lg overflow-hidden"
      >
        <div className="p-6 border-b">
          <h2 className="text-2xl font-bold">Recent Transactions</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4 font-semibold text-gray-600">User</th>
                <th className="text-left p-4 font-semibold text-gray-600">Plan</th>
                <th className="text-left p-4 font-semibold text-gray-600">Amount</th>
                <th className="text-left p-4 font-semibold text-gray-600">Date</th>
                <th className="text-left p-4 font-semibold text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentTransactions.map((transaction) => (
                <tr key={transaction.id} className="border-b">
                  <td className="p-4">{transaction.user}</td>
                  <td className="p-4">{transaction.plan}</td>
                  <td className="p-4">{transaction.amount}</td>
                  <td className="p-4">{transaction.date}</td>
                  <td className="p-4">
                    <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-600">
                      {transaction.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminBilling;

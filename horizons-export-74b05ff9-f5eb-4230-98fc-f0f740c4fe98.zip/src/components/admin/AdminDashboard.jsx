
import React from "react";
import { motion } from "framer-motion";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Users, FileText, DollarSign, TrendingUp } from "lucide-react";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const AdminDashboard = () => {
  const stats = [
    { title: "Total Users", value: "1,234", icon: Users, trend: "+12%" },
    { title: "Receipts Generated", value: "5,678", icon: FileText, trend: "+8%" },
    { title: "Revenue", value: "$12,345", icon: DollarSign, trend: "+15%" },
    { title: "Active Subscriptions", value: "890", icon: TrendingUp, trend: "+5%" }
  ];

  const chartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Users",
        data: [650, 750, 850, 950, 1100, 1234],
        borderColor: "rgb(34, 197, 94)",
        tension: 0.4
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top"
      }
    }
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-3xl shadow-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="h-12 w-12 bg-green-100 rounded-2xl flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-green-600 font-medium">{stat.trend}</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stat.value}</h3>
            <p className="text-gray-600">{stat.title}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-3xl shadow-lg p-6"
      >
        <h2 className="text-2xl font-bold mb-6">User Growth</h2>
        <Line data={chartData} options={chartOptions} />
      </motion.div>
    </div>
  );
};

export default AdminDashboard;

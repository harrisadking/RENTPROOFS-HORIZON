
import React from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";

const TestimonialSection = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Property Manager",
      content: "RentProofs has streamlined our entire receipt generation process. It's a game-changer for property management!",
      rating: 5,
      image: "professional-woman"
    },
    {
      name: "Michael Chen",
      role: "Tenant",
      content: "Finally, a simple solution for getting proper rent receipts. Perfect for my visa application process.",
      rating: 5,
      image: "young-professional"
    },
    {
      name: "Emily Rodriguez",
      role: "Real Estate Agent",
      content: "I recommend RentProofs to all my clients. It's professional, fast, and incredibly user-friendly.",
      rating: 5,
      image: "real-estate-agent"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-xl text-gray-600">Trusted by thousands of happy customers</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100"
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <div className="flex items-center mb-6">
                <div className="mr-4">
                  <img  
                    className="w-16 h-16 rounded-full object-cover"
                    alt={testimonial.name}
                   src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                  <p className="text-gray-600">{testimonial.role}</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 italic">&ldquo;{testimonial.content}&rdquo;</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;

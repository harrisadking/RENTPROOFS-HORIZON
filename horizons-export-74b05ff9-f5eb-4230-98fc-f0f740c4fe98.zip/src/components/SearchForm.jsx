
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DollarSign, Calendar, Home, Clock } from "lucide-react";

const SearchForm = () => {
  const [formData, setFormData] = useState({
    amount: "",
    rentType: "",
    startDate: "",
    endDate: "",
    paymentMethod: "",
    propertyAddress: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="search-card"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-lg font-semibold">Rent Amount</Label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
            <Input
              id="amount"
              placeholder="1000.00"
              className="pl-10"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="rentType" className="text-lg font-semibold">Rent Type</Label>
          <Select
            value={formData.rentType}
            onValueChange={(value) => setFormData({ ...formData, rentType: value })}
          >
            <SelectTrigger id="rentType" className="w-full">
              <SelectValue placeholder="Select rent type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month2month">Month to Month</SelectItem>
              <SelectItem value="year2year">Year to Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="startDate" className="text-lg font-semibold">Start Date</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
              <Input
                id="startDate"
                type="date"
                className="pl-10"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="endDate" className="text-lg font-semibold">End Date</Label>
            <div className="relative">
              <Clock className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
              <Input
                id="endDate"
                type="date"
                className="pl-10"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="paymentMethod" className="text-lg font-semibold">Payment Method</Label>
          <Select
            value={formData.paymentMethod}
            onValueChange={(value) => setFormData({ ...formData, paymentMethod: value })}
          >
            <SelectTrigger id="paymentMethod" className="w-full">
              <SelectValue placeholder="Select payment method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cash">Cash</SelectItem>
              <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
              <SelectItem value="check">Check</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="propertyAddress" className="text-lg font-semibold">Property Address</Label>
          <div className="relative">
            <Home className="absolute left-3 top-2.5 h-5 w-5 text-green-500" />
            <Input
              id="propertyAddress"
              placeholder="Enter property address"
              className="pl-10"
              value={formData.propertyAddress}
              onChange={(e) => setFormData({ ...formData, propertyAddress: e.target.value })}
            />
          </div>
        </div>

        <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-lg py-6">
          Generate Receipt
        </Button>
      </form>
    </motion.div>
  );
};

export default SearchForm;


import React from "react";
import { motion } from "framer-motion";
import { Clock, Shield, Download, FileText, Users, Settings } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: Clock,
      title: "Instant Generation",
      description: "Create professional rent receipts in under 60 seconds"
    },
    {
      icon: Shield,
      title: "Secure & Reliable",
      description: "Bank-grade security for all your rental documentation"
    },
    {
      icon: Download,
      title: "Easy Downloads",
      description: "Get your receipts instantly in PDF format"
    },
    {
      icon: FileText,
      title: "Multiple Templates",
      description: "Choose from various professional receipt templates"
    },
    {
      icon: Users,
      title: "Multi-tenant Support",
      description: "Manage receipts for multiple properties and tenants"
    },
    {
      icon: Settings,
      title: "Customizable",
      description: "Personalize receipts with your own branding"
    }
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-5" />
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-4xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Why Choose RentProofs?
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            Everything you need to manage your rental receipts in one place
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <div className="h-14 w-14 bg-green-100 rounded-2xl flex items-center justify-center mb-6">
                  <Icon className="h-7 w-7 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
        >
          <div className="inline-flex items-center gap-4 bg-green-50 rounded-full px-6 py-2">
            <span className="flex h-2 w-2 rounded-full bg-green-600" />
            <span className="text-green-600 font-medium">Trusted by 10,000+ users worldwide</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;

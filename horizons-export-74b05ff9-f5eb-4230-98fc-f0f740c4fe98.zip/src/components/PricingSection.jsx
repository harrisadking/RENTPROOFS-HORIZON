
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { loadStripe } from "@stripe/stripe-js";
import { Check } from "lucide-react";

const PricingSection = () => {
  const plans = [
    {
      name: "Free",
      price: "0",
      features: [
        "1 receipt per month",
        "Basic receipt template",
        "Download as PDF",
      ],
      priceId: "free"
    },
    {
      name: "Basic",
      price: "5.99",
      features: [
        "Up to 5 receipts per month",
        "Access to ledger",
        "Email receipts",
        "Priority support"
      ],
      priceId: "price_basic123"
    },
    {
      name: "Premium",
      price: "9.99",
      features: [
        "Unlimited receipts",
        "Custom branding",
        "Downloadable ledger",
        "Google login",
        "Premium support"
      ],
      priceId: "price_premium123"
    }
  ];

  const handleSubscribe = async (priceId) => {
    if (priceId === "free") {
      // Handle free plan signup
      return;
    }

    try {
      const stripe = await loadStripe(process.env.STRIPE_PUBLISHABLE_KEY);
      // Redirect to Stripe checkout
      await stripe.redirectToCheckout({
        lineItems: [{ price: priceId, quantity: 1 }],
        mode: "subscription",
        successUrl: window.location.origin + "/dashboard",
        cancelUrl: window.location.origin + "/pricing",
      });
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
          <p className="text-xl text-gray-600">Choose the plan that works best for you</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-lg p-8 hover:shadow-xl transition-shadow"
            >
              <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
              <div className="mb-6">
                <span className="text-4xl font-bold">${plan.price}</span>
                <span className="text-gray-600">/month</span>
              </div>
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center text-gray-600">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button
                className="w-full bg-green-600 hover:bg-green-700"
                onClick={() => handleSubscribe(plan.priceId)}
              >
                Get Started
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;

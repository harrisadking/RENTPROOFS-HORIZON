
import React from "react";
import { motion } from "framer-motion";
import SearchForm from "@/components/SearchForm";

const HeroSection = () => {
  return (
    <section className="relative py-20 overflow-hidden hero-pattern">
      <div className="absolute inset-0 bg-gradient-to-r from-green-50 to-emerald-50 opacity-90" />
      <div className="absolute inset-0 bg-grid-pattern opacity-5" />
      
      <div className="container mx-auto px-4 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.h1 
              className="text-6xl font-bold mb-6 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Generate{" "}
              <span className="gradient-text">Professional Rent Receipts</span>{" "}
              in Seconds
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 mb-8 leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Perfect for visa applications, tax records, and proof of payments. Create, download, and manage your rent receipts with ease.
            </motion.p>
            
            <motion.div
              className="flex gap-4 items-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <img alt="Trusted by thousands" className="h-12" src="https://images.unsplash.com/photo-1485531865381-286666aa80a9" />
              <p className="text-sm text-gray-500">Trusted by thousands of tenants worldwide</p>
            </motion.div>
          </div>

          <SearchForm />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;


import React from "react";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin, Ticket } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gradient-to-b from-green-900 to-green-950 text-white pt-20 pb-10">
      <div className="container mx-auto px-4">
        {/* Ticket-style section */}
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-16 ticket-edge">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <h3 className="text-4xl font-bold mb-2">10K+</h3>
              <p className="text-green-300">Happy Users</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold mb-2">50K+</h3>
              <p className="text-green-300">Receipts Generated</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold mb-2">99%</h3>
              <p className="text-green-300">Satisfaction Rate</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold mb-2">24/7</h3>
              <p className="text-green-300">Customer Support</p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div>
            <img 
              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/74b05ff9-f5eb-4230-98fc-f0f740c4fe98/3f316f39fa6ab3f7a45cbb6a6c63cceb.png" 
              alt="RentProofs Logo" 
              className="h-8 mb-6 brightness-0 invert"
            />
            <p className="text-green-300 mb-6">Your trusted partner for rent payment documentation. Making rent receipts simple, professional, and instant.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-green-300 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-green-300 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-green-300 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-green-300 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Features
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Pricing
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Templates
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6">Company</h4>
            <ul className="space-y-4">
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="text-green-300 hover:text-white transition-colors flex items-center gap-2">
                  <Ticket className="h-4 w-4" />
                  Press Kit
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-center text-green-300">
                <Mail className="h-5 w-5 mr-3" />
                support@rentproofs.com
              </li>
              <li className="flex items-center text-green-300">
                <Phone className="h-5 w-5 mr-3" />
                +1 (555) 123-4567
              </li>
              <li className="flex items-center text-green-300">
                <MapPin className="h-5 w-5 mr-3" />
                123 Business Ave, Suite 100<br />New York, NY 10001
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-green-800 pt-8 mt-8">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="text-green-300 text-sm">
              © 2025 RentProofs.com. All rights reserved.
            </div>
            <div className="md:text-right">
              <nav className="flex flex-wrap gap-4 md:justify-end">
                <a href="#" className="text-green-300 hover:text-white text-sm transition-colors">Privacy Policy</a>
                <a href="#" className="text-green-300 hover:text-white text-sm transition-colors">Terms of Service</a>
                <a href="#" className="text-green-300 hover:text-white text-sm transition-colors">Cookie Policy</a>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import React, { useState } from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { FileText, History, Settings as SettingsIcon, LogOut, Download } from "lucide-react";
import { jsPDF } from "jspdf";
import ReceiptForm from "@/components/ReceiptForm";

const DashboardPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("receipts");

  const handleLogout = () => {
    // Clear user data from localStorage
    localStorage.removeItem("currentUser");
    navigate("/auth?mode=login");
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <motion.div
        initial={{ x: -250 }}
        animate={{ x: 0 }}
        className="w-64 bg-white shadow-lg"
      >
        <div className="p-6">
          <img
            src="https://storage.googleapis.com/hostinger-horizons-assets-prod/74b05ff9-f5eb-4230-98fc-f0f740c4fe98/185733bb0f59506bd2140680d5b4099b.png"
            alt="RentProofs Logo"
            className="h-12 w-auto mb-8"
          />
          <nav className="space-y-2">
            <Button
              variant={activeTab === "receipts" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("receipts")}
            >
              <FileText className="mr-2 h-5 w-5" />
              Create Receipt
            </Button>
            <Button
              variant={activeTab === "history" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("history")}
            >
              <History className="mr-2 h-5 w-5" />
              Receipt History
            </Button>
            <Button
              variant={activeTab === "settings" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("settings")}
            >
              <SettingsIcon className="mr-2 h-5 w-5" />
              Settings
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-5 w-5" />
              Logout
            </Button>
          </nav>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="container mx-auto px-6 py-8">
          {activeTab === "receipts" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-3xl font-bold mb-8">Create Receipt</h1>
              <ReceiptForm />
            </motion.div>
          )}

          {activeTab === "history" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold">Receipt History</h1>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Download className="mr-2 h-5 w-5" />
                  Export History
                </Button>
              </div>
              {/* Receipt history table will be implemented here */}
            </motion.div>
          )}

          {activeTab === "settings" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-3xl font-bold mb-8">Settings</h1>
              {/* Settings content will be implemented here */}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;


import React from "react";
import { motion } from "framer-motion";
import { Calendar, User, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "@/components/Footer";

const BlogPage = () => {
  const blogPosts = [
    {
      id: 1,
      title: "Understanding Rent Receipts: A Complete Guide",
      excerpt: "Learn everything you need to know about rent receipts, their importance, and how they can benefit both tenants and landlords.",
      author: "Team RentProofs",
      date: "2025-04-20",
      image: "rent-receipts-guide",
      category: "Education"
    },
    {
      id: 2,
      title: "5 Ways to Streamline Your Rental Documentation",
      excerpt: "Discover effective strategies to organize and manage your rental documentation efficiently using digital tools.",
      author: "Team RentProofs",
      date: "2025-04-18",
      image: "rental-documentation",
      category: "Tips & Tricks"
    },
    {
      id: 3,
      title: "The Importance of Digital Rent Receipts",
      excerpt: "Why digital rent receipts are becoming the new standard and how they can simplify your rental management.",
      author: "Team RentProofs",
      date: "2025-04-15",
      image: "digital-receipts",
      category: "Digital Solutions"
    }
  ];

  return (
    <>
      <section className="py-20 bg-gradient-to-b from-green-50 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center mb-16"
          >
            <h1 className="text-5xl font-bold mb-6">RentProofs Blog</h1>
            <p className="text-xl text-gray-600">
              Insights, tips, and updates about rental documentation
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="p-6">
                  <span className="inline-block px-4 py-1 rounded-full text-sm font-medium bg-green-100 text-green-600 mb-4">
                    {post.category}
                  </span>
                  <h2 className="text-2xl font-bold mb-4">{post.title}</h2>
                  <p className="text-gray-600 mb-6">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2" />
                      {post.author}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      {post.date}
                    </div>
                  </div>
                  <Link
                    to={`/blog/${post.id}`}
                    className="inline-flex items-center text-green-600 font-medium hover:text-green-700"
                  >
                    Read More
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default BlogPage;

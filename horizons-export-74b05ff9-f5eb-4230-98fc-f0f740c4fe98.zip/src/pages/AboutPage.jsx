
import React from "react";
import { motion } from "framer-motion";
import Footer from "@/components/Footer";

const AboutPage = () => {
  return (
    <>
      <section className="py-20 bg-gradient-to-b from-green-50 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-5xl font-bold mb-6">About RentProofs</h1>
            <p className="text-xl text-gray-600 mb-12">
              Simplifying rent documentation for tenants and landlords worldwide
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                At RentProofs, we're committed to making rent documentation simple, 
                secure, and accessible for everyone. Our platform helps tenants and 
                landlords manage their rental relationships with ease and professionalism.
              </p>
              <p className="text-lg text-gray-600">
                We understand the importance of proper documentation for visa applications, 
                tax purposes, and maintaining clear rental records. That's why we've created 
                a solution that makes this process effortless.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="rounded-3xl overflow-hidden shadow-2xl"
            >
              <img  alt="Team working together" src="https://images.unsplash.com/photo-1637622124152-33adfabcc923" />
            </motion.div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white p-8 rounded-3xl shadow-lg"
            >
              <h3 className="text-2xl font-bold mb-4">Our Values</h3>
              <ul className="space-y-4 text-gray-600">
                <li>• Transparency in all operations</li>
                <li>• Security of user data</li>
                <li>• Excellence in service</li>
                <li>• User-centric approach</li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-white p-8 rounded-3xl shadow-lg"
            >
              <h3 className="text-2xl font-bold mb-4">Our Impact</h3>
              <ul className="space-y-4 text-gray-600">
                <li>• 10,000+ active users</li>
                <li>• 50,000+ receipts generated</li>
                <li>• 99% satisfaction rate</li>
                <li>• Global reach</li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white p-8 rounded-3xl shadow-lg"
            >
              <h3 className="text-2xl font-bold mb-4">Our Future</h3>
              <ul className="space-y-4 text-gray-600">
                <li>• Continuous innovation</li>
                <li>• Expanding services</li>
                <li>• Global partnerships</li>
                <li>• Enhanced features</li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default AboutPage;


import React from "react";
import { motion } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import Footer from "@/components/Footer";

const FAQPage = () => {
  const [openIndex, setOpenIndex] = React.useState(null);

  const faqs = [
    {
      question: "What is RentProofs?",
      answer: "RentProofs is a professional rent receipt generation platform that helps tenants and landlords create, manage, and store rent payment documentation. Our service provides instant, legally-valid receipts that can be used for visa applications, tax purposes, and record-keeping."
    },
    {
      question: "How do I generate a rent receipt?",
      answer: "Simply log in to your account, click on 'Create Receipt', fill in the required details like payment amount, date, and method, then click generate. Your receipt will be instantly created with a unique transaction ID and can be downloaded as a PDF."
    },
    {
      question: "Are the receipts legally valid?",
      answer: "Yes, all receipts generated through RentProofs are legally valid documents. Each receipt includes a unique transaction ID, landlord signature requirement, and all necessary payment details required for official documentation."
    },
    {
      question: "What payment methods can be included on the receipt?",
      answer: "Our receipts support various payment methods including cash, check, and money order. For checks and money orders, you can include the reference number on the receipt for better tracking."
    },
    {
      question: "Can I customize my receipts?",
      answer: "Yes, premium users can customize their receipts with their own branding, logo, and additional fields. Basic users have access to our standard professional template."
    },
    {
      question: "How long are my receipts stored?",
      answer: "All receipts are securely stored in your account indefinitely. You can access, download, or email your receipt history at any time from your dashboard."
    }
  ];

  return (
    <>
      <section className="py-20 bg-gradient-to-b from-green-50 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center mb-16"
          >
            <h1 className="text-5xl font-bold mb-6">Frequently Asked Questions</h1>
            <p className="text-xl text-gray-600">
              Find answers to common questions about RentProofs
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="mb-4"
              >
                <button
                  className="w-full bg-white rounded-2xl shadow-md p-6 text-left transition-all duration-200 hover:shadow-lg"
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                >
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">{faq.question}</h3>
                    {openIndex === index ? (
                      <Minus className="h-5 w-5 text-green-600" />
                    ) : (
                      <Plus className="h-5 w-5 text-green-600" />
                    )}
                  </div>
                  {openIndex === index && (
                    <p className="mt-4 text-gray-600">{faq.answer}</p>
                  )}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default FAQPage;

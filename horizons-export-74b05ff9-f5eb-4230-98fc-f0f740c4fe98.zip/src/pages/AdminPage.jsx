
import React from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Users, 
  FileText, 
  CreditCard, 
  BarChart, 
  Settings as SettingsIcon, 
  LogOut 
} from "lucide-react";
import AdminDashboard from "@/components/admin/AdminDashboard";
import AdminUsers from "@/components/admin/AdminUsers";
import AdminTemplates from "@/components/admin/AdminTemplates";
import AdminBilling from "@/components/admin/AdminBilling";
import AdminSettings from "@/components/admin/AdminSettings";

const AdminPage = () => {
  const navigate = useNavigate();
  
  // Check if user is admin
  React.useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    if (!user.isAdmin) {
      navigate("/auth?mode=login");
    }
  }, [navigate]);

  return (
    <div className="min-h-[calc(100vh-6rem)] bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-[240px,1fr] gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl shadow-lg p-6 h-fit"
          >
            <nav className="space-y-2">
              <Link to="/admin">
                <Button variant="ghost" className="w-full justify-start">
                  <BarChart className="mr-2 h-5 w-5" />
                  Dashboard
                </Button>
              </Link>
              <Link to="/admin/users">
                <Button variant="ghost" className="w-full justify-start">
                  <Users className="mr-2 h-5 w-5" />
                  Users
                </Button>
              </Link>
              <Link to="/admin/templates">
                <Button variant="ghost" className="w-full justify-start">
                  <FileText className="mr-2 h-5 w-5" />
                  Templates
                </Button>
              </Link>
              <Link to="/admin/billing">
                <Button variant="ghost" className="w-full justify-start">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Billing
                </Button>
              </Link>
              <Link to="/admin/settings">
                <Button variant="ghost" className="w-full justify-start">
                  <SettingsIcon className="mr-2 h-5 w-5" />
                  Settings
                </Button>
              </Link>
              <Button
                variant="ghost"
                className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                onClick={() => {
                  localStorage.removeItem("user");
                  navigate("/auth?mode=login");
                }}
              >
                <LogOut className="mr-2 h-5 w-5" />
                Logout
              </Button>
            </nav>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Routes>
              <Route index element={<AdminDashboard />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="templates" element={<AdminTemplates />} />
              <Route path="billing" element={<AdminBilling />} />
              <Route path="settings" element={<AdminSettings />} />
            </Routes>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;

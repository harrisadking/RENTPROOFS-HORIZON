
import React, { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { hashPassword, validatePassword, DEFAULT_ADMIN } from "@/utils/auth";

const AuthPage = () => {
  const [searchParams] = useSearchParams();
  const mode = searchParams.get("mode") || "login";
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    email: "",
    username: "",
    password: "",
    confirmPassword: ""
  });

  React.useEffect(() => {
    // Set up default admin if not exists
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    if (!users.some(user => user.email === DEFAULT_ADMIN.email)) {
      users.push(DEFAULT_ADMIN);
      localStorage.setItem("users", JSON.stringify(users));
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]");

      if (mode === "register") {
        // Validate password
        const passwordError = validatePassword(formData.password);
        if (passwordError) {
          toast({
            title: "Error",
            description: passwordError,
            variant: "destructive"
          });
          return;
        }

        if (formData.password !== formData.confirmPassword) {
          toast({
            title: "Error",
            description: "Passwords do not match",
            variant: "destructive"
          });
          return;
        }

        // Check if email or username already exists
        if (users.some(user => user.email === formData.email || user.username === formData.username)) {
          toast({
            title: "Error",
            description: "Email or username already exists",
            variant: "destructive"
          });
          return;
        }

        // Check if trying to register as admin
        if (formData.email === DEFAULT_ADMIN.email) {
          toast({
            title: "Error",
            description: "This email is reserved",
            variant: "destructive"
          });
          return;
        }
        
        // Add new user
        const newUser = {
          email: formData.email,
          username: formData.username,
          password: hashPassword(formData.password),
          role: "user",
          id: Date.now(),
          plan: "Free",
          receiptsRemaining: 1,
          isAdmin: false
        };

        users.push(newUser);
        localStorage.setItem("users", JSON.stringify(users));
        localStorage.setItem("currentUser", JSON.stringify(newUser));
        
        toast({
          title: "Success",
          description: "Account created successfully!"
        });

        navigate("/dashboard");
      } else {
        // Login
        const hashedPassword = hashPassword(formData.password);
        const user = users.find(u => 
          (u.email === formData.email || u.username === formData.email) && 
          u.password === hashedPassword
        );
        
        if (user) {
          localStorage.setItem("currentUser", JSON.stringify(user));
          
          toast({
            title: "Success",
            description: "Logged in successfully!"
          });

          // Redirect admin to admin panel, regular users to dashboard
          if (user.email === DEFAULT_ADMIN.email) {
            navigate("/admin");
          } else {
            navigate("/dashboard");
          }
        } else {
          toast({
            title: "Error",
            description: "Invalid credentials",
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-[calc(100vh-6rem)] bg-gradient-to-b from-green-50 to-white py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md mx-auto"
        >
          <div className="bg-white rounded-3xl shadow-xl p-8">
            <h1 className="text-3xl font-bold mb-6 text-center">
              {mode === "login" ? "Welcome Back" : "Create Account"}
            </h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {mode === "register" && (
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    name="username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    placeholder="Choose a username"
                    required
                  />
                </div>
              )}

              <div>
                <Label htmlFor="email">
                  {mode === "login" ? "Email or Username" : "Email"}
                </Label>
                <Input
                  id="email"
                  type={mode === "register" ? "email" : "text"}
                  placeholder={mode === "login" ? "Enter email or username" : "Enter email"}
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                />
              </div>
              
              {mode === "register" && (
                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    required
                  />
                </div>
              )}
              
              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                {mode === "login" ? "Login" : "Create Account"}
              </Button>

              {mode === "login" && (
                <Button
                  type="button"
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => {
                    toast({
                      title: "Coming Soon",
                      description: "Google login will be available soon!",
                    });
                  }}
                >
                  <img
                    src="https://www.google.com/favicon.ico"
                    alt="Google"
                    className="w-5 h-5 mr-2"
                  />
                  Continue with Google
                </Button>
              )}
            </form>
            
            <div className="mt-6 text-center">
              <p className="text-gray-600">
                {mode === "login" ? "Don't have an account?" : "Already have an account?"}
                {" "}
                <a
                  href={mode === "login" ? "?mode=register" : "?mode=login"}
                  className="text-green-600 hover:text-green-700 font-medium"
                >
                  {mode === "login" ? "Sign up" : "Login"}
                </a>
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AuthPage;


export const saveUser = (user) => {
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  users.push(user);
  localStorage.setItem("users", JSON.stringify(users));
};

export const getUser = (identifier) => {
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  return users.find(user => 
    user.email === identifier || user.username === identifier
  );
};

export const updateUser = (userId, updates) => {
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  const index = users.findIndex(user => user.id === userId);
  if (index !== -1) {
    users[index] = { ...users[index], ...updates };
    localStorage.setItem("users", JSON.stringify(users));
  }
};

export const getAllUsers = () => {
  return JSON.parse(localStorage.getItem("users") || "[]");
};

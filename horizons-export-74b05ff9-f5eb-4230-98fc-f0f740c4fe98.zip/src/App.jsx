
import React, { useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/toaster";
import { Menu, X } from "lucide-react";
import HomePage from "@/pages/HomePage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import DashboardPage from "@/pages/DashboardPage";
import AdminPage from "@/pages/AdminPage";
import AuthPage from "@/pages/AuthPage";
import FAQPage from "@/pages/FAQPage";
import BlogPage from "@/pages/BlogPage";

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <nav className="container mx-auto px-4 h-24 flex items-center justify-between">
          <div className="flex items-center gap-16">
            <Link to="/">
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/74b05ff9-f5eb-4230-98fc-f0f740c4fe98/185733bb0f59506bd2140680d5b4099b.png" 
                alt="RentProofs Logo" 
                className="h-[250px] w-[250px] mix-blend-multiply object-contain"
              />
            </Link>
            <div className="hidden md:flex items-center gap-12">
              <Link to="/" className="nav-link">Home</Link>
              <Link to="/about" className="nav-link">About Us</Link>
              <Link to="/blog" className="nav-link">Blog</Link>
              <Link to="/faq" className="nav-link">FAQ</Link>
              <Link to="/contact" className="nav-link">Contact</Link>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex gap-6">
            <Link to="/auth?mode=login">
              <Button 
                variant="ghost" 
                className="text-gray-700 hover:text-green-600 hover:bg-green-50 text-lg font-medium"
              >
                Login
              </Button>
            </Link>
            <Link to="/auth?mode=register">
              <Button 
                className="bg-green-600 hover:bg-green-700 text-lg px-8"
              >
                Sign Up
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </nav>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-4 py-4 space-y-4">
              <Link 
                to="/" 
                className="block text-gray-700 hover:text-green-600 font-medium text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/about" 
                className="block text-gray-700 hover:text-green-600 font-medium text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About Us
              </Link>
              <Link 
                to="/blog" 
                className="block text-gray-700 hover:text-green-600 font-medium text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Blog
              </Link>
              <Link 
                to="/faq" 
                className="block text-gray-700 hover:text-green-600 font-medium text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                FAQ
              </Link>
              <Link 
                to="/contact" 
                className="block text-gray-700 hover:text-green-600 font-medium text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <div className="pt-4 border-t">
                <Link 
                  to="/auth?mode=login"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button 
                    variant="ghost" 
                    className="w-full text-gray-700 hover:text-green-600 hover:bg-green-50 text-lg font-medium mb-2"
                  >
                    Login
                  </Button>
                </Link>
                <Link 
                  to="/auth?mode=register"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700 text-lg"
                  >
                    Sign Up
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/dashboard/*" element={<DashboardPage />} />
          <Route path="/admin/*" element={<AdminPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/blog" element={<BlogPage />} />
        </Routes>
      </main>

      <Toaster />
    </div>
  );
}
